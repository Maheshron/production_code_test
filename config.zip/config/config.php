<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'edelweissuser');
define('DB_PASSWORD', 'edelweissuser1');
define('DB_DATABASE', 'edelweiss');

?>